<?php 

function getQuestion($categorie, $offset) {
     require "../../database/connection.php";
    //*** Verifier si on a un administrateur;
    $pdo = Database::db_connect();
    $sql = <<<EOD
        SELECT 
        question,
        question_id,
        group_concat(choix) as choix
        FROM categories
        JOIN questions USING(categorie_id)
        JOIN reponses USING(question_id)
        WHERE nom_categorie = ?
        GROUP BY question_id
        LIMIT 1 OFFSET ?
    EOD;

    $stmt = $pdo->prepare($sql);
    $offset = 0;
    $stmt->bindParam(1, $categorie);
    $stmt->bindParam(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $stmt->execute();
    $result = $stmt->fetch();

    return $result;
 }



?>