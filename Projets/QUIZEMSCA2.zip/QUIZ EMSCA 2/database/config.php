<?php
$host = "localhost";
$dbname = "emsquiz";
$username = "root";
$pwd = "Eva/25112002";
$admin_pseudo = "admin";
$admin_mdp = "admin";
?>
