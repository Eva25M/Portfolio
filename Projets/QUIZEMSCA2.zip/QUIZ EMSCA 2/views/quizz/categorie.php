<?php
$title = "Choisir une categorie!";
$style = "categorie.css";
require_once "../partials/header.php";
?>

<div class="choice_type">
        <div class="demi_blanche">
            <div class="entete_categorie">
                <div class="titre_categorie">
                    <p>Nos catégories</p>
                </div>
                <div class="aide_titre">
                </div>
            </div>
            <div class="choice_questionnaire">
                <div class="colonne1">
                    <button class="box" type="button">
                        <a href="/views/quizz/questions.php?categorie=htmlcss">HTML et CSS</a>
                    </button>
                    <button class="box" type="button">
                        <a href="/views/quizz/questions.php?categorie=js">JS</a>
                    </button>
                </div>
                <div class="colonne2">
                    <button class="box" type="button">
                        <a href="/views/quizz/questions.php?categorie=sql">SQL</a>
                    </button>
                    <button class="box" type="button">
                        <a href="/views/quizz/questions.php?categorie=php">PHP</a>
                    </button>
                </div>
                <div class="colonne3">
                    <button class="box" type="button">
                        <a href="/views/quizz/questions.php?categorie=c">C</a>
                    </button>
                    <!--<button class="box" type="button"></button>-->
                </div>

            </div>
            

        </div>
    </div>