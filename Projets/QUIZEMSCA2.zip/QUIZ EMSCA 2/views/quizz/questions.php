<?php
$title = "Go!!";
$style = "questions.css";
require_once "../partials/header.php";
// *** Recuperer la categorie depuis l'url
$categorie;
if (isset($_GET["categorie"])) {
    if (!isset($_SESSION["currentQuestion"])) {
        $_SESSION["currentQuestion"] = 1;
    }

    $categorie = htmlspecialchars($_GET["categorie"]);
    require "../../database/connection.php";
    //*** Verifier si on a un administrateur;
    $pdo = Database::db_connect();
    $sqlQuestions = <<<EOD
        SELECT 
        question,
        question_id,
        group_concat(choix) as choix
        FROM categories
        JOIN questions USING(categorie_id)
        JOIN reponses USING(question_id)
        WHERE nom_categorie = ?
        GROUP BY question_id
        LIMIT 1 OFFSET ?
    EOD;

    $sqlCategorie_id = <<<EOL
        SELECT 
        categorie_id
        FROM categories
        WHERE nom_categorie = ?
    EOL;

    $sqlCount = <<<EOL
        SELECT COUNT(*) as total_questions
        FROM questions
        WHERE categorie_id = ?;
    EOL;

    $sqlRightAnswer = <<<EOL
        SELECT choix
        FROM emsquiz.reponses_correctes
        JOIN reponses 
            on reponse_id = reponses_reponse_id
        WHERE questions_question_id = ?;
    
    EOL;

    // *** Question
    // *** Question
    $stmt = $pdo->prepare($sqlQuestions);
    $offset = $_SESSION["currentQuestion"] - 1;
    echo $offset;
    $stmt->bindParam(1, $categorie);
    $stmt->bindParam(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $stmt->execute();
    $result = $stmt->fetch();

    // bonne reponses par question
    $question_id = $result["question_id"];
    $stmt = $pdo->prepare($sqlRightAnswer);
    $stmt->execute([$question_id]);
    $rightanswer = $stmt->fetch();
    //var_dump($rightanswer);

    // *** Categorie_id
    $stmt = $pdo->prepare($sqlCategorie_id);
    $stmt->execute([$categorie]);
    $category_id = $stmt->fetch();
    $category_id =  $category_id["categorie_id"];

    // *** total of questions
    $stmt = $pdo->prepare($sqlCount);
    $stmt->execute([$category_id]);
    $count = $stmt->fetch();
    $totalQuestions = $count["total_questions"] < 10 ? "0" .  $count["total_questions"] : $count["total_questions"];
    //if($_SESSION["currentQuestion"] == $totalQuestions){
    //  session_unset();
    //   header('Location: http://localhost:8080/views/quizz/resultat.php');
    //}
}

?>
<div class="question_reponse" id="question_reponse">
    <div class="carreblanc">
        <div class="top">
            <p>QUIZZ HTML/ CSS</p>
            <div class="topright">
                <h6> <?= $_SESSION["currentQuestion"] <= 9 ? "0" . $_SESSION["currentQuestion"] : +$_SESSION["currentQuestion"] ?> / <?= $totalQuestions ?></h6>
            </div>
        </div>
        <div class="middle">
            <h3><?= $result["question"] ?></h3>
        </div>
        <div class="bottomtop">
            <?php foreach (explode(",", $result["choix"])  as $choix) : ?>
                <button class="clair" id="clair" <?= $rightanswer["choix"] === $choix ? "data-id=true" : "data-id=false"  ?>>
                    <?= $choix ?>
                </button>
            <?php endforeach ?>
        </div>
        <div class="bottombottom">
            <?php if ($_SESSION["currentQuestion"]  < $count["total_questions"]) : ?>
                <a href="/views/quizz/questions.php?categorie=<?= $categorie ?>&question=<?= ++$_SESSION["currentQuestion"] ?>">Question Suivante</a>
            <?php else : ?>
                <a href="/views/quizz/resultat.php">Aller au resultat </a>
            <?php endif ?>
        </div>
    </div>
</div>

<script>
    const choix = document.querySelectorAll(".bottomtop button")
    
    let counter =  localStorage.getItem("counter")  || 0
    choix.forEach(c => {
        c.addEventListener("click", () => {
            if (c.dataset.id === "true") {
                counter++
                localStorage.setItem("counter", counter)
                c.style.backgroundColor = "#08A94E"
                choix.forEach(c => c.disabled = true)
            } else {
                c.style.backgroundColor = "tomato"
                choix.forEach(c => c.disabled = true)
            }
        })
    })
</script>
<?php
?>