const logout = document.querySelector("#logout")

if(logout) {
    setTimeout(() => {
        logout.remove()
    }, 5000)
}